FIDAN GALLERY — QUICK START

Files:
- index.html   HTML structure
- style.css    visual design and responsive layout
- script.js    artwork data, search/filter, modal, navigation, animations, and image fallbacks

To run:
1. Keep all three files in the same folder.
2. Open index.html in a modern browser, or use VS Code with the Live Server extension.
3. An internet connection is needed for remote artwork images and Google Fonts.

Image loading:
The page tries Wikimedia Commons FilePath sources in sequence. If a remote source fails, it tries an alternate file and then uses a clearly labelled locally generated reference visual rather than displaying a broken-image icon. The fallback is not a reproduction of the original artwork. Image/source availability may vary by network and jurisdiction; visit each source page for licensing and reuse details.

The contact form is a local demo and does not send messages to a server.
